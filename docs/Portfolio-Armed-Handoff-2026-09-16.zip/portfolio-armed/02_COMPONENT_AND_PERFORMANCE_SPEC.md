# مواصفات المكوّنات والميزانية

| المكوّن | المسؤولية | ما لا يفعله |
|---|---|---|
| `effects-gate.ts` | قراءة العلم مرة واحدة وإرجاع قرار واضح | لا يقرأ أسراراً ولا يغيّر DOM |
| `use-reduced-motion.ts` | listener واحد لـ`matchMedia` مع cleanup | لا يفترض قيمة أثناء SSR تسبب hydration mismatch |
| `live-amman-clock.tsx` | عرض الوقت والتاريخ، interval واحد، pause/resume | لا يستخدم `aria-live` ولا يغيّر عرض الحاوية |
| `node-field-canvas.tsx` | Canvas خلفي responsive مع DPR capped | لا يلتقط pointer ولا يشغّل loop خارج viewport |
| `reading-progress.tsx` | تقدم قراءة مبني على scroll range صالح | لا يغيّر flow ولا يحجب skip link |

## ميزانية التنفيذ

- كود الميزات اليدوي المستهدف ≤8KB gzip؛ قِس ولا تخمّن.
- لا package جديد قبل إثبات أن API المتصفح لا يكفي.
- Canvas واحد لكل بطل، و`devicePixelRatio` محدود إلى 2.
- Resize عبر `ResizeObserver` مع تهدئة، وpointer event passive حيث يصلح.
- Canvas `aria-hidden="true"`, `pointer-events:none`, خلف المحتوى، وأبعاده محجوزة.
- الألوان من CSS variables الحالية فقط، opacity بين 0.25 و0.35.
- لا اتصال بين كل زوج من العقد بلا حد؛ استخدم مسافة قصوى أو spatial bucketing إن ظهر حمل زائد.

## سلوك الساعة

- مصدر الوقت `new Date()` مع `Intl.DateTimeFormat` و`timeZone:'Asia/Amman'`، لا offset ثابت.
- إعادة المحاذاة مع بداية الثانية لتقليل الانجراف مقبولة، لكن يبقى مؤقت فعال واحد فقط.
- عند `document.hidden=true` امسح المؤقت؛ عند العودة حدّث فوراً ثم أعده.
- skeleton ثابت العرض أو قيمة SSR مستقرة لمنع CLS/hydration mismatch.

## سلوك Canvas

- motion العادي: تحديث positions وربط القريب وتأثير مؤشر محدود.
- reduced motion: frame ثابت بعد القياس، بلا RAF ولا تتبع pointer.
- tab hidden أو hero خارج viewport: صفر frames.
- إزالة كل listener/observer/RAF عند unmount.

